# Real pinned CLI universal-bundle prototype

Local-only feasibility passed on 2026-09-08. No publication, Rust rebuild, version
change, production packaging edit, real registry credential use or live AIRS API
operation occurred. The source repository is unchanged by this experiment.

## Verified result

Both npm10.9.8 and npm12.0.2 installed the real package using its ordinary scoped
name with @cdot65 mapped to the loopback private registry. Each installation then
launched the unchanged source154 Linux native (SHA 2fcb93d5...e3ad), reported managed
CLI 5.2.0, retained SDK 0.28.0, and passed the existing validate_prisma_cli.py contract:
trusted config and explicit environment precedence; project dotenv exclusion;
doctor missing-credential checks without API probes; 20 capability help contracts;
real PDF/PNG/JPEG/SVG/DOCX corpus generation, including actual Sharp native loading.

The parent task's CLI/SDK literal pins are unchanged. Every one of 73 selected
packages came from its package-lock.json resolved public URL with exact SHA512
verification. The reachable lock graph excludes unsupported Sharp native targets.
All 73 installed package versions match that lock. Both manifests remain private.

The packed universal CLI bundle is 43,089,708bytes (41.09MiB), SHA256
163222209bc2f89f1babd6ec9d1e04bae58751b629937fc08a1796e9e9b84283.
Its npm-reported unpacked size is 139,024,179bytes. All 69 recognized source license,
notice and copyright files survived packing and both installations byte-for-byte.
Package license declarations and archive SRI values are in preparation.json.
The separate experimental Linux native archive is 150,127,860bytes, compressed at
gzip level 1 for the fixture; it is not part of the 43.1MB launcher figure.

The local install elapsed times were 2.727s and 2.796s. These are loopback transfer
measurements, not predictions for real networks or desktop machines.

## Sharp payloads

The bundle includes only requested native families: Linux x64 glibc and musl,
Apple Silicon darwin-arm64, and Windows win32-x64. The seven Sharp/native-libvips
packages plus platform-neutral @img/colour are listed in SUMMARY.json. File-header
inspection confirms arm64 Mach-O, x86-64 ELF and x64 PE payloads. No Intel Mac
archive was downloaded, bundled or built. Upstream package metadata still lists
unsupported optional packages, but none of their payloads entered this artifact.

All supported payload packages remained present after npm10 and npm12 installation
on Linux. The musl runtime loaded its correct Sharp implementation and generated
images. Actual glibc Linux, macOS and Windows execution remains unvalidated.

## Registry and provenance boundaries

Each fresh install made exactly 4 requests, all to the private loopback host:
launcher metadata, scoped native metadata, launcher archive and native archive.
There were zero public requests, zero public @cdot65 lookups, zero unexpected
auth identities and zero synthetic credential values in npm output. No npm remote
allow override was supplied. Scripts/audit/funding requests were disabled.
The two-host positive auth control remains in the preceding synthetic experiment;
this complete bundle requires no public fetch during consumer installation.

The optional native dependency uses its actual scoped name and exact registry
version. The prototype copied release_review's in-progress scoped launcher module;
its exact SHA and package manifest are recorded. It did not edit that source file.
Only a real Linux Rust package was served. No Mac/Windows Rust installation is
claimed by this experiment. The existing private alpha.9 bytes cannot be promoted
or overwrite a previously published version merely because bundling now works.

## Limits and next reviewed implementation

The prototype bounds each dependency archive to 64 MiB, each extracted archive to
128MiB, total extracted dependencies to 256 MiB, the launcher archive to 64 MiB, and
the separate native fixture archive to 256 MiB. Extraction accepts one validated
safe top-level directory, regular files/directories only, no traversal or links,
and verifies SRI before extraction. It preserves upstream files and runs no
package build/install lifecycle scripts. Future production tooling should add
its own adversarial extraction and publication-gate tests before integration.

Root review is required before converting this operator prototype into maintained
packaging. Needed acceptance: actual supported OS/native library execution, full
license inventory review, immutable lock/integrity enforcement, signed final
Rust packages with a new coherent version, fresh real GitHub scoped installs and
teammate read access. No release-readiness or all-platform score is awarded here.

Files: build.py and install.py are the exact local operator sources; preparation.json
records all dependency URLs/SRIs/license hashes; npm-pack.json records npm's packed
file list; pack-summary.json records archive checks; install-results.json records
both full consumer results and sanitized request paths; SUMMARY.json indexes
hashes, limits, payload formats and limitations. All files remain under
/var/tmp/airs-real-cli-bundle-prototype pending root review.
