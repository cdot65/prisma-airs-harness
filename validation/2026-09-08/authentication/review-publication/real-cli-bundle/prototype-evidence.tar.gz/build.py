"""Operator-only prototype: verified locked archives, no publish/install scripts."""
import base64, concurrent.futures, hashlib, io, json, os, shutil, subprocess, tarfile, time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/home/cdot/development/cdot65/airs-harness')
LOCK=SOURCE/'npm/airs-harness/package-lock.json'
lock=json.loads(LOCK.read_text());packages=lock['packages']
CLI='@cdot65/prisma-airs-cli'
SUPPORTED={'@img/colour','@img/sharp-linux-x64','@img/sharp-libvips-linux-x64','@img/sharp-linuxmusl-x64','@img/sharp-libvips-linuxmusl-x64','@img/sharp-darwin-arm64','@img/sharp-libvips-darwin-arm64','@img/sharp-win32-x64'}

def resolve(owner,name):
 for prefix in [Path(owner),*Path(owner).parents]:
  if prefix.name=='node_modules':continue
  candidate=str(prefix/'node_modules'/name)
  if candidate in packages:return candidate
 raise ValueError('Unresolved locked dependency '+name)

selected=set();pending=['node_modules/'+CLI]
while pending:
 name=pending.pop()
 if name in selected:continue
 selected.add(name);record=packages[name]
 for child in {**record.get('dependencies',{}),**record.get('optionalDependencies',{})}:
  if child.startswith('@img/sharp-') and child not in SUPPORTED:continue
  pending.append(resolve(name,child))
assert 'node_modules/@cdot65/prisma-airs-sdk' in selected
assert {n.removeprefix('node_modules/') for n in selected if n.startswith('node_modules/@img/')}==SUPPORTED
assert packages['node_modules/'+CLI]['version']=='5.2.0'
assert packages['node_modules/@cdot65/prisma-airs-sdk']['version']=='0.28.0'
stage=ROOT/'package';stage.mkdir()
for name in ['bin','lib','managed-cli']:shutil.copytree(SOURCE/'npm/airs-harness'/name,stage/name)
for name in ['LICENSE','NOTICE','README.md']:shutil.copy2(SOURCE/'npm/airs-harness'/name,stage/name)
for name in ['MACOS.md','PRISMA-AIRS-CLI.md']:shutil.copy2(SOURCE/name,stage/name)
manifest=json.loads((SOURCE/'npm/airs-harness/package.json').read_text())
manifest.update(name='@cdot65/prisma-airs-harness',private=True,bundleDependencies=[CLI],optionalDependencies={'@cdot65/prisma-airs-harness-linux-x64':manifest['version']})
manifest['files']+=['BUNDLE-INVENTORY.json']
(stage/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
launcher=stage/'lib/launcher.js';text=launcher.read_text();assert 'platformPackage(process.platform, process.arch, launcherManifest)' in text
archives=ROOT/'dependency-archives';archives.mkdir(exist_ok=True)

def fetch(name):
 record=packages[name];url=record['resolved'];assert urlsplit(url).scheme=='https' and urlsplit(url).hostname=='registry.npmjs.org'
 algorithm,encoded=record['integrity'].split('-',1);assert algorithm=='sha512'
 archive=archives/(hashlib.sha256(name.encode()).hexdigest()+'.tgz')
 if archive.exists():body=archive.read_bytes()
 else:
  with urlopen(Request(url,headers={'User-Agent':'AIRS-local-package-acceptance'}),timeout=60) as response:
   assert urlsplit(response.url).hostname=='registry.npmjs.org'
   body=response.read(64*1024*1024+1)
 assert len(body)<=64*1024*1024
 assert hashlib.sha512(body).digest()==base64.b64decode(encoded)
 archive=archives/(hashlib.sha256(name.encode()).hexdigest()+'.tgz');archive.write_bytes(body)
 dest=stage/name;dest.mkdir(parents=True)
 total=0;licenses=[];count=0
 with tarfile.open(fileobj=io.BytesIO(body),mode='r:gz') as tf:
  members=tf.getmembers();assert len(members)<=20000
  roots={Path(m.name).parts[0] for m in members};assert len(roots)==1
  for m in members:
   parts=Path(m.name).parts
   assert parts and parts[0] in roots and parts[0] not in ('/','..','.') and not any(x in ('..','') for x in parts)
   assert m.isfile() or m.isdir(), 'Unexpected link/device in package archive'
   total+=m.size;assert total<=128*1024*1024
   relative=Path(*parts[1:]);target=dest/relative
   if m.isdir():target.mkdir(parents=True,exist_ok=True);continue
   target.parent.mkdir(parents=True,exist_ok=True)
   payload=tf.extractfile(m).read();target.write_bytes(payload);target.chmod(m.mode&0o755);count+=1
   if any(word in str(relative).lower() for word in ['license','licence','notice','copying','copyright']):licenses.append({'path':str(Path(name)/relative),'sha256':hashlib.sha256(payload).hexdigest()})
 actual=json.loads((dest/'package.json').read_text());assert actual['version']==record['version']
 return {'path':name,'name':actual['name'],'version':actual['version'],'resolved':url,'integrity':record['integrity'],'archive_sha256':hashlib.sha256(body).hexdigest(),'archive_bytes':len(body),'unpacked_bytes':total,'files':count,'license':actual.get('license'),'license_files':licenses,'sri_verified':True}
started=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(fetch,sorted(selected)))
assert sum(x['unpacked_bytes'] for x in records)<=256*1024*1024
inventory={'source_lock_sha256':hashlib.sha256(LOCK.read_bytes()).hexdigest(),'literal_cli_version':'5.2.0','literal_sdk_version':'0.28.0','supported_sharp_payloads':sorted(SUPPORTED),'packages':records,'downloaded_bytes':sum(r['archive_bytes'] for r in records),'unpacked_bytes':sum(r['unpacked_bytes'] for r in records),'prepare_seconds':time.monotonic()-started,'install_scripts_executed':False,'intel_mac_payloads_downloaded':False,'published':False}
(stage/'BUNDLE-INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
(ROOT/'preparation.json').write_text(json.dumps(inventory,indent=2)+'\n')
print(json.dumps({k:inventory[k] for k in ['downloaded_bytes','unpacked_bytes','prepare_seconds']}),flush=True)
print('verified package count',len(records),'license files',sum(len(r['license_files']) for r in records),flush=True)
