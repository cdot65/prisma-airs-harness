"""Real bundled CLI install through two synthetic authenticated registry hosts."""
import base64,hashlib,json,os,shutil,subprocess,tarfile,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote,urlsplit
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/home/cdot/development/cdot65/airs-harness')
INSTALLED=Path('/tmp/airs-auth-final-154b-29ip7b5g/AIRS Candidate Install/lib/node_modules/airs-harness/node_modules/airs-harness-linux-x64')
NATIVE='@cdot65/prisma-airs-harness-linux-x64';NAME='@cdot65/prisma-airs-harness';VERSION='0.1.0-alpha.9'
KEYS={'private':'synthetic-bundle-private-sentinel','public':'synthetic-bundle-public-sentinel'}
native=ROOT/'native-package';shutil.copytree(INSTALLED,native)
m=json.loads((native/'package.json').read_text());m.update(name=NATIVE,private=True);(native/'package.json').write_text(json.dumps(m,indent=2)+'\n')
info=json.loads((native/'BUILD-INFO.json').read_text());expected=info['binary_sha256'];assert expected=='2fcb93d5b11e5c81f2851b94a200bf81da4adba0ecb9d60b20ab8b206e81e3ad'
with (native/'bin/airs-harness').open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected
native_archive=ROOT/'native-private.tgz'
with tarfile.open(native_archive,'w:gz',compresslevel=1) as tf:tf.add(native,arcname='package')
launcher_archive=Path(json.loads((ROOT/'pack-summary.json').read_text())['archive'])
results=[]
for label, npm in [('npm10',['node','/var/tmp/airs-npm-shrinkwrap-experiment/npm10/package/bin/npm-cli.js']),('npm12',['npm'])]:
 case=ROOT/label;case.mkdir(mode=0o700);requests=[];metadata={};archives={};servers={};urls={}
 def handler(role):
  class Registry(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):
    path=unquote(urlsplit(self.path).path);auth=self.headers.get('Authorization','')
    identity='none' if not auth else next((r for r,k in KEYS.items() if auth=='Bearer '+k),'unexpected')
    requests.append({'registry':role,'path':path,'auth_identity':identity})
    if role=='private' and identity!='private':self.send_error(401);return
    if role=='private' and path in archives:
     source=archives[path];self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Length',str(source.stat().st_size));self.end_headers()
     with source.open('rb') as f:shutil.copyfileobj(f,self.wfile)
    elif role=='private' and path in metadata:
     body=json.dumps(metadata[path]).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    else:self.send_error(404)
  return Registry
 for role,host in [('private','127.0.0.1'),('public','127.0.0.2')]:
  server=ThreadingHTTPServer((host,0),handler(role));servers[role]=server;urls[role]=f'http://{host}:{server.server_port}';threading.Thread(target=server.serve_forever,daemon=True).start()
 for manifest,archive in [(m,native_archive),(json.loads((ROOT/'package/package.json').read_text()),launcher_archive)]:
  path='/download/'+manifest['name']+'/'+VERSION+'/package.tgz';archives[path]=archive
  with archive.open('rb') as f:sri='sha512-'+base64.b64encode(hashlib.file_digest(f,'sha512').digest()).decode()
  record={**manifest,'dist':{'tarball':urls['private']+path,'integrity':sri}}
  metadata['/'+manifest['name']]={'name':manifest['name'],'dist-tags':{'latest':VERSION},'versions':{VERSION:record}}
 config=case/'user.npmrc';config.write_text('registry='+urls['public']+'/\n@cdot65:registry='+urls['private']+'/\n'+''.join('//'+urlsplit(urls[r]).netloc+'/:_authToken='+KEYS[r]+'\n' for r in urls)+'update-notifier=false\n');config.chmod(0o600)
 globalconfig=case/'global.npmrc';globalconfig.write_text('')
 env={k:v for k,v in os.environ.items() if not k.upper().startswith(('NPM_','NODE_AUTH_TOKEN'))};env.update(NPM_CONFIG_USERCONFIG=str(config),NPM_CONFIG_GLOBALCONFIG=str(globalconfig),NPM_CONFIG_CACHE=str(case/'cache'),NO_PROXY='127.0.0.1,127.0.0.2',no_proxy='127.0.0.1,127.0.0.2')
 try:
  started=time.monotonic();p=subprocess.run([*npm,'install','--global','--prefix',str(case/'prefix'),'--include=optional','--ignore-scripts','--no-audit','--no-fund',NAME+'@'+VERSION],cwd=case,env=env,capture_output=True,timeout=180)
  row={'npm':subprocess.check_output([*npm,'--version'],env=env,text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'install_exit':p.returncode,'install_seconds':time.monotonic()-started,'requests':requests,'private_auth_on_public':any(r['registry']=='public' and r['auth_identity']=='private' for r in requests),'public_auth_on_private':any(r['registry']=='private' and r['auth_identity']=='public' for r in requests),'sentinel_in_output':any(v.encode() in p.stdout+p.stderr for v in KEYS.values()),'public_cdot_lookups':[r['path'] for r in requests if r['registry']=='public' and '/@cdot65/' in r['path']]}
  if p.returncode==0:
   command=case/'prefix/bin/airs-harness';package=case/'prefix/lib/node_modules/@cdot65/prisma-airs-harness'
   row['harness_version']=subprocess.check_output([str(command),'--version'],env=env,text=True,timeout=10).strip()
   row['managed_cli_version']=subprocess.check_output([str(command),'airs','--version'],env=env,text=True,timeout=10).strip()
   installed_native=package/'node_modules'/NATIVE/'bin/airs-harness'
   with installed_native.open('rb') as f:row['native_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
   inv=json.loads((ROOT/'preparation.json').read_text());row['installed_locked_packages']=[]
   for dep in inv['packages']:
    installed=package/dep['path'];actual=json.loads((installed/'package.json').read_text());assert actual['version']==dep['version']
    row['installed_locked_packages'].append(actual['name']+'@'+actual['version'])
    for license in dep['license_files']:assert hashlib.sha256((package/license['path']).read_bytes()).hexdigest()==license['sha256']
   row['all_licenses_preserved']=True
   contract=case/'managed-cli.json';checked=subprocess.run(['python3',str(SOURCE/'scripts/validate_prisma_cli.py'),'--launcher',str(command),'--receipt',str(contract)],env=env,cwd=case,capture_output=True,timeout=180)
   row['managed_contract_exit']=checked.returncode
   if checked.returncode==0:row['managed_contract']=json.loads(contract.read_text())
   else:(case/'managed-contract-failure.log').write_bytes(checked.stdout+checked.stderr)
   row['passed']=row['managed_cli_version']=='5.2.0' and row['native_sha256']==expected and checked.returncode==0 and not row['private_auth_on_public'] and not row['public_auth_on_private'] and not row['sentinel_in_output'] and not row['public_cdot_lookups']
  else:row['passed']=False;(case/'install-failure.log').write_bytes(p.stdout+p.stderr)
  results.append(row);(case/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');(ROOT/'install-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps({k:row[k] for k in ['npm','install_exit','install_seconds','passed']}),flush=True)
 finally:
  for server in servers.values():server.shutdown();server.server_close()
