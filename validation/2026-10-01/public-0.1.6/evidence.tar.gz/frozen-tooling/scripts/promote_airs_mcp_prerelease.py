#!/usr/bin/env python3
"""Promote tested alpha native packages using bound MCP and npm acceptance receipts.

This is the internal authenticated-MCP alpha channel, not the independently
reviewed release channel. It preserves that distinction in the published bytes.
No score, independent review or full workspace validation is manufactured.
"""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
from urllib.parse import urlsplit

TOOLS = {
    "list_workspaces",
    "get_workspace",
    "list_gateway_configs",
    "get_gateway_config",
    "list_gateway_guardrails",
    "get_gateway_guardrail",
    "list_security_profiles",
    "get_security_profile",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(info, e2e, upgrade, signing, release_exception=None):
    if not info["version"].startswith("0.1.0-alpha."):
        raise ValueError("This promotion is limited to the internal alpha channel")
    routing = e2e.get("routing", {})
    gateway = urlsplit(routing.get("gateway_endpoint", ""))
    upstream = urlsplit(routing.get("upstream_endpoint", ""))
    if (
        routing.get("mode") != "gateway-proxied-mcp"
        or routing.get("gateway_endpoint") != e2e.get("endpoint")
        or gateway.scheme != "https"
        or not gateway.hostname
        or upstream.scheme != "https"
        or not upstream.hostname
        or gateway.netloc == upstream.netloc
        or gateway.username is not None
        or upstream.username is not None
        or gateway.query
        or upstream.query
        or gateway.fragment
        or upstream.fragment
    ):
        raise ValueError(
            "MCP acceptance must identify the gateway destination and separate upstream; "
            "direct-server receipts do not satisfy the required architecture"
        )
    if (release_exception is None and e2e.get("passed") is not True) or e2e.get(
        "binary_sha256"
    ) != info["binary_sha256"]:
        raise ValueError("Live MCP acceptance must bind the exact executable")
    expected_platform = {
        "aarch64-apple-darwin": "Darwin",
        "x86_64-unknown-linux-musl": "Linux",
    }[info["target"]]
    if release_exception is not None:
        from airs_alpha14_release_exception import validate_exception

        validate_exception(info, e2e, release_exception)
    else:
        if e2e.get("platform") != expected_platform or e2e.get("refresh_cycles") != 2:
            raise ValueError(
                "Both native refresh cycles must pass on the target platform"
            )
        rows = e2e["results"]
        required = {
            "inference_browser_pkce",
            "mcp_browser_pkce",
            "doctor_after_mcp",
            "inference_history_preserved",
            "mcp_logout",
            "mcp_list_after_logout",
            "inference_after_mcp_logout",
            "inference_logout",
            "gateway_cas_browser_login",
            "gateway_mcp_request_observed",
            "gateway_upstream_request_observed",
            "gateway_mcp_denial",
            "gateway_managed_upstream_oauth",
            "gateway_managed_upstream_refresh",
        }
        if any(row.get("passed") is not True for row in rows) or not required <= {
            row["case"] for row in rows
        }:
            raise ValueError(
                "Required native login/history/logout acceptance is incomplete"
            )
        tools = next(
            row for row in rows if row["case"] == "all_read_tools_tool_results"
        )
        if not TOOLS <= set(tools["tools"]):
            raise ValueError("All eight model-selected reads must succeed")
        for cycle in (1, 2):
            for process in (0, 1):
                row = next(
                    row
                    for row in rows
                    if row["case"] == f"refresh_{cycle}_{process}_tool_results"
                )
                if "list_workspaces" not in row["tools"]:
                    raise ValueError("Concurrent refreshed process did not call MCP")
    if (
        upgrade.get("passed") is not True
        or upgrade.get("version") != info["version"]
        or upgrade.get("platform") != expected_platform
    ):
        raise ValueError("In-place npm upgrade acceptance does not match")
    if (
        upgrade.get("configuration_preserved") is not True
        or upgrade.get("legacy_target_preserved") is not True
    ):
        raise ValueError(
            "Upgrade must preserve configuration and the legacy executable"
        )
    expected_cases = {
        "npm-managed-in-place",
        "legacy-one-time-migration",
        "legacy-command-before-separate-npm-prefix",
    }
    if not expected_cases <= {case["case"] for case in upgrade["cases"]}:
        raise ValueError(
            "Both legacy command layouts and ordinary npm upgrades must be tested"
        )
    for case in upgrade["cases"]:
        if (
            case.get("passed") is not True
            or case.get("binary_sha256") != info["binary_sha256"]
            or case.get("uninstall_used")
            or case.get("manual_command_removal")
        ):
            raise ValueError(
                "Upgrade did not verify the exact native bytes without removal"
            )
    managed = next(
        case for case in upgrade["cases"] if case["case"] == "npm-managed-in-place"
    )
    if managed.get("force_used"):
        raise ValueError("An npm-managed upgrade must not require force")
    if expected_platform == "Darwin":
        expected = {
            "binary_sha256": info["binary_sha256"],
            "source_commit": info["source_commit"],
            "team_id": "G5QLZ5A8TA",
            "codesign_verified": True,
            "hardened_runtime": True,
            "notarization_verified": True,
        }
        if signing is None or any(signing.get(k) != v for k, v in expected.items()):
            raise ValueError("Verified Developer ID and notarization are required")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, required=True)
    parser.add_argument("--e2e", type=Path, required=True)
    parser.add_argument("--upgrade", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--release-exception",
        type=Path,
        help="Explicit owner-authorized alpha.14 scope and measured evidence",
    )
    args = parser.parse_args()
    root = args.release.resolve(strict=True)
    info = json.loads((root / "BUILD-INFO.json").read_text())
    if digest(root / "airs-harness") != info["binary_sha256"]:
        raise ValueError("Native bytes changed")
    signing_path = root / "SIGNING.json"
    signing = json.loads(signing_path.read_text()) if signing_path.exists() else None
    if signing is not None and digest(signing_path) != info.get(
        "signing_receipt_sha256"
    ):
        raise ValueError("Signing receipt changed after native packaging")
    e2e = json.loads(args.e2e.read_text())
    upgrade = json.loads(args.upgrade.read_text())
    exception = (
        json.loads(args.release_exception.read_text())
        if args.release_exception
        else None
    )
    validate(info, e2e, upgrade, signing, exception)
    shutil.copytree(root, args.output)
    evidence = args.output / "validation-evidence"
    evidence.mkdir(exist_ok=True)
    records = []
    inputs = [("native-mcp-e2e", args.e2e), ("npm-upgrade", args.upgrade)]
    if args.release_exception:
        inputs.append(("owner-release-exception", args.release_exception))
    for role, path in inputs:
        destination = evidence / (role + ".json")
        shutil.copyfile(path, destination)
        records.append(
            {
                "role": role,
                "path": str(destination.relative_to(evidence)),
                "sha256": digest(destination),
            }
        )
    validation = {
        "schema_version": 1,
        "scope": "authenticated-mcp-internal-alpha",
        "passed": True,
        "release_ready": True,
        "full_authentication_release_ready": False,
        "independent_review": "not performed; this receipt is measured acceptance, not an independent review",
        "full_workspace_tests": "not claimed",
        "source_commit": info["source_commit"],
        "product_version": info["version"],
        "target": info["target"],
        "binary_sha256": info["binary_sha256"],
        "evidence": records,
    }
    if exception is not None:
        validation.update(
            acceptance_mode="owner-authorized-limited-alpha",
            full_gateway_lifecycle_passed=False,
            frontend_refresh_cycles_completed=0,
            limitations=exception["limitations"],
        )
    (args.output / "VALIDATION.json").write_text(
        json.dumps(validation, indent=2) + "\n"
    )
    info.pop("publishable", None)
    info.pop("release_status", None)
    info["source_repository"] = "https://git.cdot.io/cdot/prisma-airs-harness"
    info["release_scope"] = validation["scope"]
    info["validation_receipt_sha256"] = digest(args.output / "VALIDATION.json")
    (args.output / "BUILD-INFO.json").write_text(json.dumps(info, indent=2) + "\n")
    (args.output / "SHA256SUMS").write_text(
        "".join(
            f"{digest(p)}  {p.relative_to(args.output).as_posix()}\n"
            for p in sorted(args.output.rglob("*"))
            if p.is_file() and p.name != "SHA256SUMS"
        )
    )
    print(
        json.dumps(
            {
                "passed": True,
                "scope": validation["scope"],
                "binary_sha256": info["binary_sha256"],
            }
        )
    )


if __name__ == "__main__":
    main()
